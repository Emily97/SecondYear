/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ca2;

/**
 *
 * @author N00150623
 */
public abstract class Subscription {
    
    private int customerId;
    private String customerName;
    private String address;
    private String email;
    private int creditCardInfo;
    private double deliveryCharge;

    public Subscription(int id, String n, String a, String e, int cc, double c) {
        this.customerId = id;
        this.customerName = n;
        this.address = a;
        this.email = e;
        this.creditCardInfo = cc;
        this.deliveryCharge = c;
    }
    
    public abstract void printBill();
        
    

    public int getCustomerId() {
        return customerId;
    }
    
    public void setCustomerId(int id){
        this.customerId = id;
    }
    
    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String name) {
        this.customerName = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getCreditCardInfo() {
        return creditCardInfo;
    }

    public void setCreditCardInfo(int creditCardInfo) {
        this.creditCardInfo = creditCardInfo;
    }
    
    public double getDeliveryCharge() {
        return deliveryCharge;
    }

    public void setDeliveryCharge(double deliveryCharge) {
        this.deliveryCharge = deliveryCharge;
    }
    
    @Override
    public String toString()
    {
        return "Name : " + getCustomerName();
    }
    
}
