<?php

require_once 'utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCart.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCartItem.php';
require_once SITE_ROOT . SITE_PATH . '/classes/DB.php';
require_once SITE_ROOT . SITE_PATH . '/classes/BookTable.php';

start_session();

try {
    //---------------------------------------------------------------------------------------------
    // validate book id format
    //---------------------------------------------------------------------------------------------
    $id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT);
    if ($id === NULL || $id === FALSE) {
        throw new Exception("Book id required.");
    }
    $id = filter_var($id, FILTER_VALIDATE_INT);
    if ($id === FALSE) {
        throw new Exception("Book id required.");
    }

    //---------------------------------------------------------------------------------------------
    // validate book id is in database
    //---------------------------------------------------------------------------------------------
    $connection = DB::getConnection();
    $booksTable = new BookTable($connection);
    $book = $booksTable->getBookById($id);
    if ($book == null) {
        throw new Exception("Book id not found.");
    }

    //---------------------------------------------------------------------------------------------
    // get user's shopping cart
    //---------------------------------------------------------------------------------------------
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    else {
        $cart = new ShoppingCart();
        $_SESSION['cart'] = $cart;
    }
    
    //---------------------------------------------------------------------------------------------
    // add book to user's shopping cart
    //---------------------------------------------------------------------------------------------
    $cart->addToCart($id, 1);
    
    header('Location: '.SITE_PATH.'/view_books.php');
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
    require SITE_ROOT . SITE_PATH . '/view_books.php';
}
?>
