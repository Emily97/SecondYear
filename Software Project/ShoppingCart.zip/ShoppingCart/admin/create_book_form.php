<?php

require_once '../utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';

start_session();

if (!is_logged_in()) {
    header("Location: ".SITE_PATH."/login_form.php");
}

$user = $_SESSION['user'];
if (!$user['role'] === 'staff') {
    header("Location: ".SITE_PATH."/logout.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php require SITE_ROOT . SITE_PATH . '/utils/styles.php'; ?>
        <?php require SITE_ROOT . SITE_PATH . '/utils/scripts.php'; ?>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/header.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/toolbar.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <h2>Create New Book</h2>
                    <?php if (isset($errorMessage)) echo "<p>$errorMessage</p>"; ?>
                    <form method="post" action="adminCreateBook.php">
                        <table>
                            <tr>
                                <td>Title</td>
                                <td><input type="text" name="title" /></td>
                            </tr>
                            <tr>
                                <td>First Name</td>
                                <td><input type="text" name="firstName" /></td>
                            </tr>
                            <tr>
                                <td>Last Name</td>
                                <td><input type="text" name="lastName" /></td>
                            </tr>
                            <tr>
                                <td>ISBN</td>
                                <td><input type="text" name="isbn" /></td>
                            </tr>
                            <tr>
                                <td>Publisher</td>
                                <td><input type="text" name="publisher" /></td>
                            </tr>
                            <tr>
                                <td>Year</td>
                                <td><input type="text" name="year" /></td>
                            </tr>
                            <tr>
                                <td>Price</td>
                                <td><input type="text" name="price" /></td>
                            </tr>
                        </table>
                        <input type="submit" value="Add" />
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>
