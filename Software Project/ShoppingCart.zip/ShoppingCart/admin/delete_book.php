<?php

require_once '../utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/Book.php';
require_once SITE_ROOT . SITE_PATH . '/BookDAO.php';
require_once SITE_ROOT . SITE_PATH . '/User.php';

session_start();

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
}
$user = $_SESSION['user'];
if ($user->getRole() != 'admin') {
    header("location: logout.php");
}
try {
    if ($_SERVER['REQUEST_METHOD'] != "GET") {
        throw new Exception("Illegal request");
    }
    
    if (!isset($_GET['bookId']) or !$_GET['bookId']) {
        throw new Exception("Book id required.");
    }
    
    $bookId = $_GET['bookId'];
    $dao = new BookDAO();
    $book = $dao->delete($bookId);
    
    header("Location: adminViewBooks.php");
}
catch (Exception $e) {
    $errorMessage = $e->getMessage();
    require "adminViewBooks.php";
}
?>
