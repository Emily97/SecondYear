<?php

require_once '../utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/Book.php';
require_once SITE_ROOT . SITE_PATH . '/BookDAO.php';
require_once SITE_ROOT . SITE_PATH . '/User.php';

session_start();

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
}
$user = $_SESSION['user'];
if ($user->getRole() != 'admin') {
    header("location: logout.php");
}
try {
    if ($_SERVER['REQUEST_METHOD'] != "POST") {
        throw new Exception("Illegal request");
    }
    
    if (!isset($_POST['bookId']) or !$_POST['bookId']) {
        throw new Exception("Book id required.");
    }
    
    $bookId = $_POST['bookId'];
    $dao = new BookDAO();
    $book = $dao->getBook($bookId);
    
    if ($book == NULL) {
        throw new Exception("Invalid book id.");
    }
    
    $requiredFields = array("title", "firstName", "lastName", "price", "isbn");
    $missingFields = array();

    foreach ($requiredFields as $requiredField) {
        if (!isset($_POST[$requiredField]) or !$_POST[$requiredField]) {
            $missingFields[] = $requiredField;
        }
    }
    
    if (!empty($missingFields)) {
        $error = "The following fields are required: ";
        foreach ($missingFields as $field) {
            $error .= $field . " ";
        }
        throw new Exception($error);
    }
    
    $title = $_POST['title'];
    $firstName = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $price = $_POST['price'];
    $isbn = $_POST['isbn'];
    
    if (isset($_POST['publisher'])) {
        $publisher = $_POST['publisher'];
    }
    else {
        $publisher = NULL;
    }
    if (isset($_POST['year'])) {
        $year = $_POST['year'];
    }
    else {
        $year = NULL;
    }
    $book = new Book($bookId, $title, $firstName, $lastName, 
            $publisher, $isbn, $year, $price);
    
    $dao = new BookDAO();
    $dao->update($book);

    header("Location: adminViewBooks.php");
}
catch (Exception $e) {
    $errorMessage = $e->getMessage();
    require "adminViewBooks.php";
}
?>
