<?php

require_once '../utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/Book.php';
require_once SITE_ROOT . SITE_PATH . '/BookDAO.php';
require_once SITE_ROOT . SITE_PATH . '/User.php';

session_start();

if (!isset($_SESSION['user'])) {
    header("Location: index.php");
}
$user = $_SESSION['user'];
if ($user->getRole() != 'admin') {
    header("location: logout.php");
}

try {
    if ($_SERVER['REQUEST_METHOD'] != "GET") {
        throw new Exception("Illegal request");
    }
    
    if (!isset($_GET['bookId'])) {
        throw new Exception("Book id required.");
    }
    
    $bookId = $_GET['bookId'];
    $dao = new BookDAO();
    $book = $dao->getBook($bookId);
    
    if ($book == NULL) {
        throw new Exception("Invalid book id.");
    }
}
catch (Exception $e) {
    $errorMessage = $e->getMessage();
    require "adminViewBooks.php";
    exit;
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" type="text/css" href="css/default.css" />
        <link rel="stylesheet" type="text/css" href="css/toolbar.css" />
        <title></title>
    </head>
    <body>
        <?php require SITE_ROOT . SITE_PATH . '/toolbar.php'; ?>
        <h2>Edit Book</h2>
        <?php if (isset($errorMessage)) echo "<p>$errorMessage</p>"; ?>
        <form method="post" action="adminEditBook.php">
            <input type="hidden" 
                   name="bookId" 
                   value="<?php echo $book->getId() ?>" />
            <table>
                <tr>
                    <td>Title</td>
                    <td><input type="text" 
                               name="title" 
                               value="<?php echo $book->getTitle() ?>" />
                    </td>
                </tr>
                <tr>
                    <td>First Name</td>
                    <td><input type="text" 
                               name="firstName" 
                               value="<?php echo $book->getFirstName() ?>" />
                    </td>
                </tr>
                <tr>
                    <td>Last Name</td>
                    <td><input type="text" 
                               name="lastName" 
                               value="<?php echo $book->getLastName() ?>" />
                    </td>
                </tr>
                <tr>
                    <td>ISBN</td>
                    <td><input type="text" 
                               name="isbn" 
                               value="<?php echo $book->getIsbn() ?>" />
                    </td>
                </tr>
                <tr>
                    <td>Publisher</td>
                    <td><input type="text" 
                               name="publisher" 
                               value="<?php echo $book->getPublisher() ?>" />
                    </td>
                </tr>
                <tr>
                    <td>Year</td>
                    <td><input type="text" 
                               name="year" 
                               value="<?php echo $book->getYear() ?>" /></td>
                </tr>
                <tr>
                    <td>Price</td>
                    <td><input type="text" 
                               name="price" 
                               value="<?php echo $book->getPrice() ?>" /></td>
                </tr>
            </table>
            <input type="submit" value="Update" />
        </form>
    </body>
</html>
