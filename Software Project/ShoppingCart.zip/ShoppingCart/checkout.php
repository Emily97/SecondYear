<?php

require_once 'utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCart.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCartItem.php';
require_once SITE_ROOT . SITE_PATH . '/classes/DB.php';
require_once SITE_ROOT . SITE_PATH . '/classes/BookTable.php';
require_once SITE_ROOT . SITE_PATH . '/classes/CreditCardTable.php';
require_once SITE_ROOT . SITE_PATH . '/classes/OrderTable.php';

start_session();
        echo '<pre>';
        print_r($_POST);
        echo '</pre>';

try {
    //---------------------------------------------------------------------------------------------
    // make sure the user is logged in
    //---------------------------------------------------------------------------------------------
    if (!is_logged_in()) {
        header('Location: '.SITE_PATH.'/login_form.php');
    }

    //---------------------------------------------------------------------------------------------
    // make sure the user is not a staff member or administrator
    //---------------------------------------------------------------------------------------------
    $user = $_SESSION['user'];
    if ($user['role'] !== 'user') {
        header("Location: ".SITE_PATH."/logout.php");
    }
    
    //---------------------------------------------------------------------------------------------
    // make sure the user has a cart
    //---------------------------------------------------------------------------------------------
    $cart = NULL;
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    if ($cart == NULL || $cart->isEmpty()) {
        throw new Exception("Illegal request.");
    }
    
    //---------------------------------------------------------------------------------------------
    // retrieve any credit cards that are stored for the user
    //---------------------------------------------------------------------------------------------
    $connection = DB::getConnection();
    $credit_card_table = new CreditCardTable($connection);
    $cards = $credit_card_table->getCreditCardsByUserId($user['id']);

    $order_table = new OrderTable($connection);

    //---------------------------------------------------------------------------------------------
    // validate the user's credit card details
    //---------------------------------------------------------------------------------------------
    $card_id = "";
    $cctype = "";
    $ccname = "";
    $ccnumber = "";
    $ccexpiry = "";
    $cvv = "";
    $validCCTypes = array("Visa", "Master Card", "Laser");
    $errors = array();

    $card_id = filter_input(INPUT_POST, 'card-id', FILTER_SANITIZE_NUMBER_INT);
    if ($card_id === NULL || $card_id === FALSE) {
        $errors['card-id'] = "Credit card id required. ";
    } 
    else {
        $card_id = filter_var($card_id, FILTER_SANITIZE_NUMBER_INT);
        if ($card_id === FALSE) {
            $errors['card-id'] = "Invalid credit card id. ";
        }
        // if the user has selected to enter the details of a new card
        else if ($card_id == -1) {
            //validate the credit card type
            $cctype = filter_input(INPUT_POST, 'cctype', FILTER_SANITIZE_STRING);
            if ($cctype === NULL || $cctype === FALSE) {
                $errors['cctype'] = "Credit card type is required. ";
            }
            else if (!in_array($cctype, $validCCTypes)) {
                $errors['cctype'] = "Invalid credit card type.";
            }
            //validate the credit card name
            $ccname = filter_input(INPUT_POST, 'ccname', FILTER_SANITIZE_STRING);
            if ($ccname === NULL || $ccname === FALSE || $ccname === "") {
                $errors['ccname'] = "Credit card name is required. ";
            }
            //validate the credit card number
            $ccnumber = filter_input(INPUT_POST, 'ccnumber', FILTER_SANITIZE_NUMBER_INT);
            if ($ccnumber === NULL || $ccnumber === FALSE || $ccnumber === "") {
                $errors['ccnumber'] = "Credit card number is required. ";
            }
            else if (!preg_match('/^[0-9]{16}$/', $ccnumber)) {
                $errors['ccnumber'] = "Invalid credit card number.";
            }
            //validate the credit card expiry date
            $ccexpiry = filter_input(INPUT_POST, 'ccexpiry', FILTER_SANITIZE_STRING);
            if ($ccexpiry === NULL || $ccexpiry === FALSE || $ccexpiry === "") {
                $errors['ccexpiry'] = "Credit card expiry date is required. ";
            }
            else if (!preg_match('/^[0-9]{2}\/[0-9]{2}$/', $ccexpiry)) {
                $errors['ccexpiry'] = "Invalid credit card expiry date.";
            }
            //validate the credit card CVV number
            $cvv = filter_input(INPUT_POST, 'cvv', FILTER_SANITIZE_NUMBER_INT);
            if ($cvv === NULL || $cvv === FALSE || $cvv === "") {
                $errors['cvv'] = "Credit card CVV code is required. ";
            }
            else if (!preg_match('/^[0-9]{3}$/', $cvv)) {
                $errors['cvv'] = "Invalid credit card cvv: $cvv";
            }
        }
        else if (!isset($cards[$card_id])) {
            $errors['card-id'] = "Invalid credit card id. ";
        }
    }

    //---------------------------------------------------------------------------------------------
    // if there are validation errors throw an exception
    //---------------------------------------------------------------------------------------------
    if (!empty($errors)) {
        echo '<pre>';
        print_r($errors);
        echo '</pre>';
        throw new Exception("There were errors. Please fix them.");
    }
    
    //---------------------------------------------------------------------------------------------
    // if there are no validation errors, store the user's credit card details if necessary and
    // store the user;s order
    //---------------------------------------------------------------------------------------------
    $status = $connection->beginTransaction();
    if ($status !== TRUE) {
        throw new Exception("Could not start transaction");
    }

    if ($card_id == -1) {
        $id = $credit_card_table->insert($ccname, $ccnumber, $cctype, $ccexpiry, $cvv, $user['id']);
        $card = array(
            'id'      => $id,
            'name'    => $ccname,
            'number'  => $ccnumber,
            'type'    => $cctype,
            'expiry'  => $ccexpiry,
            'cvv'     => $cvv,
            'user_id' => $user['id']
        );
	} 
    else {
        $card = $cards[$card_id];
    }

    $order_table->insert($cart, $card);

    $status = $connection->commit();
    if ($status !== TRUE) {
        throw new Exception("Could not commit transaction");
    }

    header('Location: '.SITE_PATH.'/receipt.php');
}
catch (Exception $ex) {
    
    $errorMessage = $ex->getMessage();

    if ($connection->inTransaction()) {
        $status = $connection->rollBack();
        if ($status !== TRUE) {
            $errorMessage .= "; Could not commit transaction";
        }
    }

    require SITE_ROOT . SITE_PATH . '/checkout_form.php';
}
?>