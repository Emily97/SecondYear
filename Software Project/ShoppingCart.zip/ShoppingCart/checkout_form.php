<?php

require_once 'utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCart.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCartItem.php';
require_once SITE_ROOT . SITE_PATH . '/classes/DB.php';
require_once SITE_ROOT . SITE_PATH . '/classes/BookTable.php';
require_once SITE_ROOT . SITE_PATH . '/classes/CreditCardTable.php';

start_session();

try {
    //---------------------------------------------------------------------------------------------
    // make sure the user is logged in
    //---------------------------------------------------------------------------------------------
    if (!is_logged_in()) {
        header('Location: '.SITE_PATH.'/login_form.php');
    }

    //---------------------------------------------------------------------------------------------
    // make sure the user is not a staff member or administrator
    //---------------------------------------------------------------------------------------------
    $user = $_SESSION['user'];
    if ($user['role'] !== 'user') {
        header("Location: ".SITE_PATH."/logout.php");
    }
    
    //---------------------------------------------------------------------------------------------
    // make sure the user has a cart
    //---------------------------------------------------------------------------------------------
    $cart = NULL;
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    if ($cart == NULL || $cart->isEmpty()) {
        throw new Exception("Illegal request.");
    }
    
    //---------------------------------------------------------------------------------------------
    // retrieve any credit cards that are stored for the user
    //---------------------------------------------------------------------------------------------
    $connection = DB::getConnection();
    $creditCardTable = new CreditCardTable($connection);
    $cards = $creditCardTable->getCreditCardsByUserId($user['id']);

    //---------------------------------------------------------------------------------------------
    // retrieve all the books so that details of the books can be displayed
    //---------------------------------------------------------------------------------------------
    $bookTable = new BookTable($connection);
    $books = $bookTable->getBooks();
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php require SITE_ROOT . SITE_PATH . '/utils/styles.php'; ?>
        <?php require SITE_ROOT . SITE_PATH . '/utils/scripts.php'; ?>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/header.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/toolbar.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <h2>Checkout</h2>
                    <h3>Shopping cart</h3>
                    <?php
                    if (isset($errorMessage)) {
                      echo "<p>$errorMessage</p>";
                    }
                    $items = $cart->getItems();
                    $totalAmount = 0.0;
                    echo '<table class="table table-cart">';
                    echo '<tr>
                              <td>Title</td>
                              <td>Unit price</p>
                              <td>Quantity</td>
                              <td>Price</td>
                          </tr>';

                    foreach ($items as $item) {
                        $book = $books[ $item->getBookId() ];
                        $price = $book['price'];
                        $linePrice = $price * $item->getQuantity();

                        echo '<tr>';
                        echo '<td>'.$book['title'].'</td>';
                        echo '<td>'.$book['price'].'</td>';
                        echo '<td>'.$item->getQuantity().'</td>';
                        echo '<td>'.$linePrice.'</td>';
                        echo '</tr>';

                        $totalAmount = $totalAmount + $linePrice;
                    }
                    echo '<tr>
                              <td></td>
                              <td></td>
                              <th>Total price</th>
                              <td>'.$totalAmount.'</td>
                          </tr>';
                    echo '</table>';
                    ?>
                    <h3>Select credit card or enter credit card details</h3>
                    <form action="<?php echo SITE_PATH; ?>/checkout.php" method="POST">
                        <?php 
                        if (!empty($cards)) {
                            foreach ($cards as $card) {
                        ?>
                            <div class="row">
                                <div class="form-group">
                                    <div class="col-lg-1 form-label">
                                        <input type="radio" 
                                               name="card-id" 
                                               value="<?php echo $card['id'] ?>" />
                                    </div>
                                    <div class="col-lg-11"><?php echo $card['name'].' - '.$card['type'].' - '.$card['number']; ?></div>
                                </div>
                            </div>
                        <?php
                            }
                        }
                        ?>
                        <div class="row">
                            <div class="form-group">
                                <div class="col-lg-1 form-label">
                                    <input type="radio" 
                                           name="card-id" 
                                           value="-1"
                                           checked="checked"/></td>
                                </div>
                                <div class="col-lg-11">
                                    <fieldset>
                                        <legend class="fieldset-credit-card-legend">Enter new credit card details</legend>
                                        <div class="row">
                                            <div class="form-group">
                                                <div class="col-lg-2 form-label">Card type</div>
                                                <div class="col-lg-6">
                                                    <select name="cctype" class="form-control">
                                                        <option >Visa</option>
                                                        <option >Master Card</option>
                                                        <option >Laser</option>
                                                    </select>
                                                </div>
                                                <div class="col-lg-4"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <div class="col-lg-2 form-label">Name</div>
                                                <div class="col-lg-6">
                                                    <input type="text" name="ccname" class="form-control" value="" />
                                                </div>
                                                <div class="col-lg-4"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <div class="col-lg-2 form-label">Number</div>
                                                <div class="col-lg-6">
                                                    <input type="text" name="ccnumber" class="form-control" value="" />
                                                </div>
                                                <div class="col-lg-4"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <div class="col-lg-2 form-label">Expiry date</div>
                                                <div class="col-lg-6">
                                                    <input type="text" name="ccexpiry" class="form-control" value="" />
                                                </div>
                                                <div class="col-lg-4"></div>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="form-group">
                                                <div class="col-lg-2 form-label">CVV</div>
                                                <div class="col-lg-6">
                                                    <input type="text" name="cvv" class="form-control" value="" />
                                                </div>
                                                <div class="col-lg-4"></div>
                                            </div>
                                        </div>
                                    </fieldset>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="form-group col-lg-12">
                                <input class="btn btn-danger" type="submit" value="Submit order" name="submit" />
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/footer.php'; ?>
                </div>
            </div>
        </div>
    </body>
</html>

