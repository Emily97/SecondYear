<?php

class BookTable {

    protected $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function insert($title, $firstName, $lastName, $publisher, $isbn, $year, $price) {

        $sql = "INSERT INTO books(title, firstName, lastName, publisher, isbn, year, price) 
                VALUES (:title, :firstName, :lastName, :publisher, :isbn, :year, :price)";

        $params = array(
            'title'     => $title,
            'firstName' => $firstName,
            'lastName'  => $lastName,
            'publisher' => $publisher,
            'isbn'      => $isbn,
            'year'      => $year,
            'price'     => $price
        );

        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);

        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not save book: " . $errorInfo[2]);
        }

        $id = $this->connection->lastInsertId('books');

        return $id;
    }

    public function delete($id) {

        $sql = "DELETE FROM books WHERE id = :id";

        $params = array('id' => $id);

        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);

        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not delete book: " . $errorInfo[2]);
        }

        return $stmt->rowCount();
    }

    public function update($id, $title, $firstName, $lastName, $publisher, $isbn, $year, $price) {

        $sql = "UPDATE books SET
                    title = :title,
                    firstName = :firstName,
                    lastName = :lastName,
                    publisher = :publisher,
                    isbn = :isbn,
                    year = :year,
                    price = :price
                WHERE id = :id";

        $params = array(
            'id'        => $id,
            'title'     => $title,
            'firstName' => $firstName,
            'lastName'  => $lastName,
            'publisher' => $publisher,
            'isbn'      => $isbn,
            'year'      => $year,
            'price'     => $price
        );

        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);

        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not update book: " . $errorInfo[2]);
        }

        return $stmt->rowCount();
    }

    public function getBookById($id) {

        $sql = "SELECT * FROM books WHERE id = :id";

        $params = array('id' => $id);

        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);

        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not retrieve book: " . $errorInfo[2]);
        }

        $book = null;
        if ($stmt->rowCount() == 1) {
            $book = $stmt->fetch();
        }

        return $book;
    }

    public function getBooks() {
        $sql = "SELECT * FROM books";
        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute();
        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not retrieve books: " . $errorInfo[2]);
        }

        $books = array();
        $book = $stmt->fetch();
        while ($book != null) {
            $id = $book['id'];
            $books[$id] = $book;
            $book = $stmt->fetch();
        }

        return $books;
    }
}
?>