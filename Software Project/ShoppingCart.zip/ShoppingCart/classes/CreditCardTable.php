<?php

class CreditCardTable {

    protected $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function insert($name, $number, $type, $expiry, $ccv, $user_id) {

        $sql = "INSERT INTO credit_cards(name, number, type, expiry, ccv, user_id) 
                VALUES (:name, :number, :type, :expiry, :ccv, :user_id)";

        $params = array(
            'name'    => $name, 
            'number'  => $number,
            'type'    => $type, 
            'expiry'  => $expiry, 
            'ccv'     => $ccv, 
            'user_id' => $user_id
        );

        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);

        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not save credit card: " . $errorInfo[2]);
        }

        $id = $this->connection->lastInsertId('credit_cards');
        
        return $id;
    }

    public function delete($id) {
        
        $sql = "DELETE FROM credit_cards WHERE id = :id";
        
        $params = array('id' => $id);
        
        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);
        
        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not delete credit card: " . $errorInfo[2]);
        }

        return $stmt->rowCount();
    }

    public function update($id, $name, $number, $type, $expiry, $ccv, $user_id) {

        $sql = "UPDATE credit_cards SET
                    name = :name,
                    number = :number, 
                    type = :type,
                    expiry = :expiry, 
                    ccv = :ccv
                WHERE id = :id";

        $params = array(
            'id'      => $id,
            'name'    => $name, 
            'number'  => $number,
            'type'    => $type, 
            'expiry'  => $expiry, 
            'ccv'     => $ccv
        );

        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);

        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not update credit card: " . $errorInfo[2]);
        }

        return $stmt->rowCount();
    }

    public function getCreditCardById($id) {

        $sql = "SELECT * FROM credit_cards WHERE id = :id";

        $params = array('id' => $id);

        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);

        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not retrieve credit card: " . $errorInfo[2]);
        }

        $creditCard = null;
        if ($stmt->rowCount() == 1) {
            $creditCard = $stmt->fetch();
        }

        return $creditCard;
    }

    public function getCreditCardsByUserId($userId) {

        $sql = "SELECT * FROM credit_cards WHERE user_id = :userId";

        $params = array('userId' => $userId);

        $stmt = $this->connection->prepare($sql);
        $status = $stmt->execute($params);

        if ($status != true) {
            $errorInfo = $stmt->errorInfo();
            throw new Exception("Could not retrieve credit cards: " . $errorInfo[2]);
        }

        $creditCards = array();
        $creditCard = $stmt->fetch();
        while ($creditCard != null) {
            $id = $creditCard['id'];
            $creditCards[$id] = $creditCard;
            $creditCard = $stmt->fetch();
        }

        return $creditCards;
    }
}
?>