<?php
class DB {

    public static function getConnection() {
        $host = "daneel";
        $db = "john";
        $user = "john";
        $pass = "secret";

        $dbinfo = "mysql:host=$host;dbname=$db";

        $connection = new PDO($dbinfo, $user, $pass);

        return $connection;
    }
}
?>