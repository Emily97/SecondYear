<?php

require_once SITE_ROOT . SITE_PATH . '/classes/BookTable.php';

class OrderTable {

    protected $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function insert($cart, $card) {

        $bookTable = new BookTable($this->connection);
        $books = $bookTable->getBooks();

        $items = $cart->getItems();
        $totalAmount = 0.0;
        foreach ($items as $item) {
            $book = $books[ $item->getBookId() ];
            $price = $book['price'];
            $quantity = $item->getQuantity();
            $totalAmount = $totalAmount + ($price * $quantity);
        }

        $sql_orders = "INSERT INTO orders(amount, date, card_id) VALUES (:amount, :date, :card_id)";

		date_default_timezone_set(UTC);
		
        $params_orders = array(
            'amount'  => $totalAmount, 
            'date'    => date('Y-m-d'), 
            'card_id' => $card['id']
        );

        $stmt_orders = $this->connection->prepare($sql_orders);
        $status = $stmt_orders->execute($params_orders);

        if ($status != true) {
            $errorInfo = $stmt_orders->errorInfo();
            throw new Exception("Could not save order: " . $errorInfo[2]);
        }

        $orderId = $this->connection->lastInsertId('orders');

        $sql_items = "INSERT INTO book_orders(order_id, book_id, quantity) VALUES (:order_id, :book_id, :qty)";

        $stmt_items = $this->connection->prepare($sql_items);
        
        foreach ($items as $item) {
            $params_items = array(
                'order_id' => $orderId, 
                'book_id'  => $item->getBookId(), 
                'qty'      => $item->getQuantity()
            );

            $status = $stmt_items->execute($params_items);

            if ($status != true) {
                $errorInfo = $stmt_items->errorInfo();
                throw new Exception("Could not save book_order: " . $errorInfo[2]);
            }
        }
    }
}
?>