<?php
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCartItem.php';

class ShoppingCart {

    private $items;

    public function __construct() {
        $this->items = array();
    }

    public function getItems() { return $this->items; }

    public function addToCart($bookId, $qty) {
        if (isset($this->items[$bookId])) {
            $item = $this->items[$bookId];
            $oldQuantity = $item->getQuantity();
            $item->setQuantity($oldQuantity + $qty);
        }
        else {
            $item = new ShoppingCartItem($bookId, $qty);
            $this->items[$bookId] = $item;
        }
    }

    public function updateCart($bookId, $qty) {
        if (isset($this->items[$bookId])) {
            if ($qty > 0) {
                $item = $this->items[$bookId];
                $item->setQuantity($qty);
            }
            else if ($qty == 0) {
                $this->item[$bookId] = NULL;
                unset($this->items[$bookId]);
            }
        }
        else {
            throw new Exception("Illegal request.");
        }
    }

    public function isEmpty() {
        return empty($this->items);
    }
    
    public function removeAll() {
        $this->items = array();
    }
}
?>