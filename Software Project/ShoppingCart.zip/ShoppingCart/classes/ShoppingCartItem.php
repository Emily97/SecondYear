<?php

class ShoppingCartItem {

    private $bookId;
    private $quantity;

    public function  __construct($id, $qty) {
        $this->bookId = $id;
        $this->quantity = $qty;
    }

    public function getBookId() { return $this->bookId; }
    public function getQuantity() { return $this->quantity; }
    public function setQuantity($qty) { $this->quantity = $qty; }
}
?>