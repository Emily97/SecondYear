<?php require_once 'utils/config.php'; ?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php require SITE_ROOT . SITE_PATH . '/utils/styles.php'; ?>
        <?php require SITE_ROOT . SITE_PATH . '/utils/scripts.php'; ?>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/header.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/toolbar.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <h2>Welcome to the Acme Inc Website</h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/footer.php'; ?>
                </div>
            </div>
        </div>
    </body>
</html>