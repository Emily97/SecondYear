<?php

require_once 'utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';

if (!is_logged_in()) {
    header("Location: ".SITE_PATH."/login_form.php");
}
else {
	unset($_SESSION['user']);

	header("Location: ".SITE_PATH."/login_form.php");
}
?>
