<?php
require_once SITE_ROOT . SITE_PATH . '/../ShoppingCart.php';
require_once SITE_ROOT . SITE_PATH . '/../User.php';

session_start();

try {
    if (!isset($_GET['bookNo']) || empty($_GET['bookNo'])) {
        throw new Exception("Book no required.");
    }
    
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    else {
        $cart = new ShoppingCart();
        $_SESSION['cart'] = $cart;
    }
    
    $cart->addToCart($_GET['bookNo'], 1);
    
    header('Location: viewCart.php');
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
    require SITE_ROOT . SITE_PATH . '/viewBooks.php';
}
?>
