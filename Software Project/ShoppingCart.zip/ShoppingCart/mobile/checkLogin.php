<?php
$session_id = session_id();
if (empty($session_id)) session_start();

$user = NULL;
if (isset($_SESSION['user'])) {
    $_SESSION['user'] = NULL;
    unset($_SESSION['user']);
}

require_once SITE_ROOT . SITE_PATH . '/../User.php';
require_once SITE_ROOT . SITE_PATH . '/../UserDAO.php';

try {
    // get an array of the registered users
    $userDAO = new UserDAO();
    $users = $userDAO->getUsers();
    
    // initialise the form validation variables
    $errorMessage = null;
    $valid = false;

    // throw an exception if the form fields are 
    // empty
    if (empty($_POST['username'])) {
        throw new Exception("Username required");
    }
    if (empty($_POST['password'])) {
        throw new Exception("Password required");
    }

    // since the form fields are not empty, store
    // them in local variables
    $username = $_POST['username'];
    $password = $_POST['password'];

    // search for a user with the submitted username
    // if a match is found then check if the submitted
    // password matches the user's password; if the 
    // passwords do not match then throw an exception;
    // break out of the loop if a match of the submitted
    // username matches (there is no point continuing)
    foreach ($users as $user) {
        if ($user->getEmail() == $username) {
            if ($user->getPassword() == $password) {
                // a match for the username and password
                // has been found
                $valid = true;
            }
            else {
                throw new Exception("Invalid password");
            }
            break;
        }
    }
    // if a match of the username and password was not
    // found then throw an exception
    if (!$valid || $user->getRole() != 'www') {
        throw new Exception("Invalid username");
    }
    // otherwise determine the next (home) page for the 
    // user based on their role
    else {
        $nextPage = 'viewBooks.php';
    }
    // store the user object in the session array using
    // the key 'user'
    $_SESSION['user'] = $user;
    // redirect the user to their home page (rather than
    // requiring the home page here)
    // 
    // require SITE_ROOT . SITE_PATH . '/home.php';
    header('Location:'.$nextPage);
}
// catch any exception and return the user to the login
// form with an error message
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
    require SITE_ROOT . SITE_PATH . '/index.php';
}
?>
