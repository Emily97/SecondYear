<?php
try {
    require_once SITE_ROOT . SITE_PATH . '/../ShoppingCart.php';
    require_once SITE_ROOT . SITE_PATH . '/../Book.php';
    require_once SITE_ROOT . SITE_PATH . '/../BookDAO.php';
    require_once SITE_ROOT . SITE_PATH . '/../User.php';
    require_once SITE_ROOT . SITE_PATH . '/../CreditCardDAO.php';
    require_once SITE_ROOT . SITE_PATH . '/../CreditCard.php';

    $session_id = session_id();
    if (empty($session_id)) session_start();
    
    if (!isset($_SESSION['user'])) {
        header('Location: index.php');
    }
    $user = $_SESSION['user'];
    if ($user->getRole() != 'www') {
        header("location: ".SITE_PATH."/logout.php");
    }
    
    $cart = NULL;
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    if ($cart == NULL || $cart->isEmpty()) {
        throw new Exception("Illegal request.");
    }
        
    $creditCardDAO = new CreditCardDAO();
    $cards = $creditCardDAO->getCreditCardsByUserId($user->getId());

    $booksDAO = new BookDAO();
    $books = $booksDAO->getBooks();
    
    $items = $cart->getItems();
    $totalAmount = 0.0;
    foreach ($items as $item) {
        $book = $books[ $item->getBookId() ];
        $totalAmount = $totalAmount +
            ($book->getPrice() * $item->getQuantity());
    }
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
    require SITE_ROOT . SITE_PATH . '/viewBooks.php';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.css" /> 
        <link rel="stylesheet" type="text/css" href="css/default.css" />
        <link rel="stylesheet" type="text/css" href="css/toolbar.css" />
        <script src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
        <script src="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.js"></script>
        <script type="text/javascript" src="../js/validate.js"></script>
        <title>Checkout Form</title>
    </head>
    <body>
        <div data-role="page">
            <div data-role="header" data-position="fixed">
                <a href="viewBooks.php" data-rel="back" data-role="button">Back</a>
                <h1>Shopping Cart</h1>
            </div>
            <div data-role="content">	
                <?php if (isset($errorMessage)) echo "<p>$errorMessage</p>"; ?>
                <form action="checkout.php" method="POST">
                    <fieldset data-role="controlgroup">
                        <legend>Credit card details</legend>
                        <?php 
                        if (!empty($cards)) {
                            $checked = 'checked="checked"';
                            foreach ($cards as $card) {
                                echo '<input type="radio" 
                                             name="cardId" 
                                             id="cardId'.$card->getId().'"
                                             value="'.$card->getId().'"
                                             '.$checked.'/>
                                      <label for="cardId'.$card->getId().'">'.$card->getType().' '.$card->getNumber().'</label>';
                                $checked = '';
                            }
                        }
                        ?>
                    </fieldset> 
                    <input type="submit" value="Submit Order" name="submit" />
                    <a href="createCreditCardForm.php" data-role="button">Create New Card</a>
                </form>
            </div>
            <div data-role="footer" class="tabbar" data-id="main-tabbar" data-position="fixed">
		<div data-role="navbar" class="tabbar">
                    <ul>
                        <li><a href="index.php" data-icon="star">Logout</a></li>
                        <li><a href="viewBooks.php" data-icon="home">Catalogue</a></li>
                        <li><a href="search.php" data-icon="search">Search</a></li>
                        <li><a href="viewCart.php" data-icon="grid" class="ui-btn-active ui-state-persist">Cart</a></li>
                    </ul>
		</div>
            </div>		
        </div>
    </body>
</html>
