<?php
try {
    require_once SITE_ROOT . SITE_PATH . '/../ShoppingCart.php';
    require_once SITE_ROOT . SITE_PATH . '/../User.php';

    $session_id = session_id();
    if (empty($session_id))
        session_start();

    if (!isset($_SESSION['user'])) {
        header('Location: index.php');
    }
    $user = $_SESSION['user'];
    if ($user->getRole() != 'www') {
        header("location: logout.php");
    }

    $cart = NULL;
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    if ($cart == NULL || $cart->isEmpty()) {
        throw new Exception("Illegal request.");
    }
} catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
    require SITE_ROOT . SITE_PATH . '/viewBooks.php';
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.css" /> 
        <link rel="stylesheet" type="text/css" href="css/default.css" />
        <link rel="stylesheet" type="text/css" href="css/toolbar.css" />
        <style>
            label {
                float: left;
                width: 5em;
            }
            input.ui-input-text {
                display: inline !important;
                width: 25em !important;
            }
            form p {
                clear:left;
                margin:1px;
            }
        </style>
        <script src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
        <script src="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.js"></script>
        <title>Checkout Form</title>
    </head>
    <body>
        <?php
        if (isset($errorMessage))
            echo "<p>$errorMessage</p>";
        ?>
        <h2>Select credit card or enter credit card details</h2>
        <form action="createCreditCard.php" method="POST">
            <p>
                <label for="cctype">Card type</label>
                <select name="cctype" id="cctype">
                    <option>Visa</option>
                    <option>Master Card</option>
                    <option>Laser</option>
                </select>
            </p>
            <p>
            <label for="ccname">Name</label>
            <input type="text" name="ccname" id="ccname" value="" />
            </p>
            <p>
            <label for="ccnumber">Number</label>
            <input type="text" name="ccnumber" id="ccnumber" value="" />
            </p>
            <p>
            <label for="ccexpiry">Expiry</label>
            <input type="text" name="ccexpiry" id="ccexpiry" value="" />
            </p>
            <p>
            <label for="ccv">CCV</label>
            <input type="text" name="ccv" id="ccv" value="" />
            </p>
            <p>
            <input type="submit" value="Create Card" name="submit" />
            </p>
        </form>
    </body>
</html>
