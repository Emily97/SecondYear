<?php
$session_id = session_id();
if (empty($session_id)) session_start();

$user = NULL;
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
}
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.css" /> 
        <link rel="stylesheet" type="text/css" href="css/default.css" />
        <link rel="stylesheet" type="text/css" href="css/toolbar.css" />
        <style>
            label {
                float: left;
                width: 5em;
            }
            input.ui-input-text {
                display: inline !important;
                width: 12em !important;
            }
            form p {
                clear:left;
                margin:1px;
            }
        </style>
        <script src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
        <script src="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.js"></script>
        <title>View Books</title>
    </head>
    <body>
        <div data-role="page">
            <div data-role="header" data-position="fixed">
                <a href="viewBooks.php" data-rel="back" data-role="button">Back</a>
                <h1>Shopping Cart</h1>
            </div>
            <div data-role="content">	
                <?php
                if (isset($errorMessage))
                    echo "<p>$errorMessage</p>";
                ?>
                <form action="checkLogin.php" method="POST">
                    <p>
                        <label for="username">Username:</label>
                        <input type="text" id="username" name="username" value="" />
                    </p>
                    <p>
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password"  value="" />
                    </p>
                    <input type="submit" value="Login" />
                </form>
                <p><a href="registerForm.php" data-role="button">Register</a></p>
            </div>
            <div data-role="footer" class="tabbar" data-id="main-tabbar" data-position="fixed">
		<div data-role="navbar" class="tabbar">
                    <ul>
                        <?php if ($user != NULL) { ?>
                        <li><a href="logout.php" data-icon="star">Logout</a></li>
                        <?php } else { ?>
                        <li><a href="index.php" data-icon="star">Login</a></li>
                        <?php } ?>
                        <li><a href="viewBooks.php" data-icon="home">Catalogue</a></li>
                        <li><a href="search.php" data-icon="search">Search</a></li>
                        <li><a href="viewCart.php" data-icon="grid">Cart</a></li>
                    </ul>
		</div>
            </div>		
        </div>
    </body>
</html>
