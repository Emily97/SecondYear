<?php
require_once SITE_ROOT . SITE_PATH . '/../Book.php';
require_once SITE_ROOT . SITE_PATH . '/../BookDAO.php';
require_once SITE_ROOT . SITE_PATH . '/../User.php';

$session_id = session_id();
if (empty($session_id)) session_start();

$user = NULL;
if (isset($_SESSION['user'])) {
    $user = $_SESSION['user'];
}

$booksDAO = new BookDAO();
$books = $booksDAO->getBooks();
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.css" /> 
        <link rel="stylesheet" type="text/css" href="css/default.css" />
        <link rel="stylesheet" type="text/css" href="css/toolbar.css" />
        <script src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
        <script src="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.js"></script>
        <title>View Books</title>
    </head>
    <body>
        <div data-role="page">
            <div data-role="header" data-position="fixed">
                <h1>Books</h1>
            </div>
            <div data-role="content">	
                <?php if (isset($errorMessage))
                    echo "<p>$errorMessage</p>"; ?>
                <?php if (!empty($books)) { ?>
                    <ul data-role="listview">
                        <?php foreach ($books as $book) { ?>
                        <li>
                            <a href="viewBook.php?bookNo=<?php echo $book->getId(); ?>">
                                <h3><?php echo $book->getTitle(); ?></h3>
                                <p><?php echo $book->getFirstName() . ' ' . $book->getLastName(); ?></p>
                                <p><?php echo $book->getPrice(); ?></p>
                            </a>
                        </li>
                        <?php } ?>
                    </ul>
                <?php } else {
                    echo "<p>There are no books in the database.</p>";
                } ?>
            </div>
            <div data-role="footer" class="tabbar" data-id="main-tabbar" data-position="fixed">
		<div data-role="navbar" class="tabbar">
                    <ul>
                        <?php if ($user != NULL) { ?>
                        <li><a href="logout.php" data-icon="star">Logout</a></li>
                        <?php } else { ?>
                        <li><a href="index.php" data-icon="star">Login</a></li>
                        <?php } ?>
                        <li><a href="viewBooks.php" data-icon="home" class="ui-btn-active ui-state-persist">Home</a></li>
                        <li><a href="search.php" data-icon="search">Search</a></li>
                        <li><a href="viewCart.php" data-icon="grid">Cart</a></li>
                    </ul>
		</div>
            </div>		
        </div>
    </body>
</html>
