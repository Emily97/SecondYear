<?php
try {
    require_once SITE_ROOT . SITE_PATH . '/../ShoppingCart.php';
    require_once SITE_ROOT . SITE_PATH . '/../Book.php';
    require_once SITE_ROOT . SITE_PATH . '/../BookDAO.php';
    require_once SITE_ROOT . SITE_PATH . '/../User.php';

    $session_id = session_id();
    if (empty($session_id)) session_start();

    $user = NULL;
    if (isset($_SESSION['user'])) {
        $user = $_SESSION['user'];
    }

    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    else {
        $cart = new ShoppingCart();
        $_SESSION['cart'] = $cart;
    }

    $dao = new BookDAO();
    $books = $dao->getBooks();
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
    require SITE_ROOT . SITE_PATH . '/viewBooks.php';
}
?>
<!DOCTYPE HTML>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.css" /> 
        <link rel="stylesheet" type="text/css" href="css/default.css" />
        <link rel="stylesheet" type="text/css" href="css/toolbar.css" />
        <script src="http://code.jquery.com/jquery-1.6.4.min.js"></script>
        <script src="http://code.jquery.com/mobile/1.0/jquery.mobile-1.0.min.js"></script>
        <title>View Cart</title>
    </head>
    <body>
        <div data-role="page">
            <div data-role="header" data-position="fixed">
                <a href="viewBooks.php" data-rel="back" data-role="button">Back</a>
                <h1>Shopping Cart</h1>
            </div>
            <div data-role="content">	
            <?php
            if (isset($errorMessage)) echo "<p>$errorMessage</p>";
            $items = $cart->getItems();
            if (!empty($items)) {
                $totalAmount = 0.0;
                echo '<ul data-role="listview">';
                foreach ($items as $item) {
                    $book = $books[ $item->getBookId() ];
                    echo '<li>';
                    echo '<h3>'. $book->getTitle() . '</h3>';
                    echo '<p>' . $book->getFirstName() . ' ' . $book->getLastName() . '</p>';
                    echo '<p>Price: ' . $book->getPrice() . '</p>';
                    echo '<p>Quantity: ' . $item->getQuantity() . '</p>';
                    echo '</li>';
                    $totalAmount = $totalAmount +
                        ($book->getPrice() * $item->getQuantity());
                }
                echo '</ul>';
                echo '<p>Total: ' . $totalAmount . '</p>';
                echo '<p><a href="checkoutForm.php">Checkout</a></p>';
            }
            else {
                echo '<p>Your shopping cart is empty.</p>';
            }
            ?>
            </div>
            <div data-role="footer" class="tabbar" data-id="main-tabbar" data-position="fixed">
		<div data-role="navbar" class="tabbar">
                    <ul>
                        <?php if ($user != NULL) { ?>
                        <li><a href="logout.php" data-icon="star">Logout</a></li>
                        <?php } else { ?>
                        <li><a href="index.php" data-icon="star">Login</a></li>
                        <?php } ?>
                        <li><a href="viewBooks.php" data-icon="star">Catalogue</a></li>
                        <li><a href="search.php" data-icon="search">Search</a></li>
                        <li><a href="viewCart.php" data-icon="grid" class="ui-btn-active ui-state-persist">Cart</a></li>
                    </ul>
		</div>
            </div>		
        </div>
    </body>
</html>
