<?php

require_once 'utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCart.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCartItem.php';
require_once SITE_ROOT . SITE_PATH . '/classes/DB.php';
require_once SITE_ROOT . SITE_PATH . '/classes/BookTable.php';
require_once SITE_ROOT . SITE_PATH . '/classes/CreditCardTable.php';
require_once SITE_ROOT . SITE_PATH . '/classes/OrderTable.php';

start_session();

try {
    //---------------------------------------------------------------------------------------------
    // make sure the user is logged in
    //---------------------------------------------------------------------------------------------
    if (!is_logged_in()) {
        header('Location: '.SITE_PATH.'/login_form.php');
    }

    //---------------------------------------------------------------------------------------------
    // make sure the user is not a staff member or administrator
    //---------------------------------------------------------------------------------------------
    $user = $_SESSION['user'];
    if ($user['role'] !== 'user') {
        header("Location: ".SITE_PATH."/logout.php");
    }
    
    //---------------------------------------------------------------------------------------------
    // make sure the user has a cart
    //---------------------------------------------------------------------------------------------
    $cart = NULL;
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    if ($cart == NULL || $cart->isEmpty()) {
        throw new Exception("Illegal request.");
    }
    
    //---------------------------------------------------------------------------------------------
    // retrieve all the books so that details of the books can be displayed
    //---------------------------------------------------------------------------------------------
    $connection = DB::getConnection();
    $bookTable = new BookTable($connection);
    $books = $bookTable->getBooks();
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
    require SITE_ROOT . SITE_PATH . '/viewBooks.php';
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php require SITE_ROOT . SITE_PATH . '/utils/styles.php'; ?>
        <?php require SITE_ROOT . SITE_PATH . '/utils/scripts.php'; ?>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/header.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/toolbar.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                <?php
                $items = $cart->getItems();
                $totalAmount = 0.0;
                echo '<table class="table table-cart">';
                echo '<tr><td>Title</td><td>Unit price</td><td>Quantity</td><td>Price</td></tr>';
                foreach ($items as $item) {
                    $book = $books[ $item->getBookId() ];
                    $price = $book['price'];
                    $linePrice = $price * $item->getQuantity();

                    echo '<tr>';
                    echo '<td>'.$book['title'].'</td>';
                    echo '<td>'.$book['price'].'</td>';
                    echo '<td>'.$item->getQuantity().'</td>';
                    echo '<td>'.$linePrice.'</td>';
                    echo '</tr>';
                    $totalAmount = $totalAmount + $linePrice;
                }
                echo '<tr><td></td><td></td><th>Total</th><td>'.$totalAmount.'</td></tr>';
                echo '</table>';
                echo '<p>Your order has been successfully submitted.</p>';
                $cart->removeAll();
                ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/footer.php'; ?>
                </div>
            </div>
        </div>
    </body>
</html>
