function validateForm(form) {
    var valid = true;

    var cardId = getRadioCheckedValue(form, 'cardId');
    if (cardId == "-1") {
        var ccNameError = document.getElementById('ccNameError');
        var ccNumberError = document.getElementById('ccNumberError');
        var ccExpiryError = document.getElementById('ccExpiryError');
        var ccvError = document.getElementById('ccvError');

        valid = validateCCName(form.elements['ccname'], ccNameError) && valid;
        valid = validateCCNumber(form.elements['ccnumber'], ccNumberError) && valid;
        valid = validateCCExpiry(form.elements['ccexpiry'], ccExpiryError) && valid;
        valid = validateCCV(form.elements['ccv'], ccvError) && valid;
    }
    return valid;
}

function validateRegEx(regex, input, helpText, helpMessage) {
    // See if the input data validates OK
    if (!regex.test(input)) {
        // The data is invalid, so set the help
        // message and return false
        if (helpText != null)
            helpText.innerHTML = helpMessage;
        return false;
    }
    else {
        // The data is OK, so clear the help message
        // and return true
        if (helpText != null)
            helpText.innerHTML = "";
        return true;
    }
}

function validateNonEmpty(inputField, helpText) {
    var errorMessage = "Please enter a value."
    var valid = validateRegEx(/.+/,
                              inputField.value,
                              helpText,
                              errorMessage);

    return valid;
}

function validateCCName(inputField, helpText) {
    var errorMessage = "Please enter a valid name "
                     + "(acceptable chars a-z A-Z . , ')";

    var valid = validateRegEx(/^[a-zA-Z \.,']+$/,
                              inputField.value,
                              helpText,
                              errorMessage);

    return valid;
}

function validateCCNumber(inputField, helpText) {
    var errorMessage = "Please enter a valid (16-digit) "
                     + "credit card number.";

    var valid = validateRegEx(/^[0-9]{16}$/,
                              inputField.value,
                              helpText,
                              errorMessage);

    return valid;
}

function validateCCExpiry(inputField, helpText) {
    var errorMessage = "Please enter a valid expiry "
                     + "date (mm/yy).";

    var valid = validateRegEx(/^[0-9]{2}\/[0-9]{2}$/,
                              inputField.value,
                              helpText,
                              errorMessage);

    return valid;
}

function validateCCV(inputField, helpText) {
    var errorMessage = "Please enter a valid (3-digit) "
                     + "credit card number.";

    var valid = validateRegEx(/^[0-9]{3}$/,
                              inputField.value,
                              helpText,
                              errorMessage);

    return valid;
}

function getRadioCheckedValue(form, radioName) {
    var radioButtons = form.elements[radioName];
    for(var i = 0; i < radioButtons.length; i++) {
        if(radioButtons[i].checked) {
            return radioButtons[i].value;
        }
    }
    return '';
}