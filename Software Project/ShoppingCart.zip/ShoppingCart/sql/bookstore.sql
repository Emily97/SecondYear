DROP TABLE IF EXISTS users;
CREATE TABLE  users (
  id int(11) NOT NULL AUTO_INCREMENT,
  email varchar(50) NOT NULL,
  password varchar(30) NOT NULL,
  role varchar(10) NOT NULL,
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS books;
CREATE TABLE  books (
  id int(11) NOT NULL AUTO_INCREMENT,
  title varchar(50) NOT NULL,
  firstName varchar(20) NOT NULL,
  lastName varchar(20) NOT NULL,
  isbn varchar(12) NOT NULL,
  publisher varchar(40) NOT NULL,
  year int(11) NOT NULL,
  price decimal(6,2) NOT NULL,
  PRIMARY KEY (id)
);

INSERT INTO books(id, title, firstName, lastName, publisher, isbn, year, price) VALUES
 (1,'Java Programming','Joe','Bloggs','Java Press','1234567890123',2010,'21.99'),
 (2,'PHP Programming','Harry','Hughes','PHP Press','2345678901234',2009,'19.99'),
 (3,'JavaScript Programming','Jane','Jones','JS Press','3456789012345',2010,'23.00'),
 (4,'Game Programming','Kevin','Kelly','Game Press','4567890123456',2006,'33.99'),
 (5,'CSS Design','Mary','Moore','CSS Press','5678901234567',2005,'35.99');

DROP TABLE IF EXISTS orders;
CREATE TABLE  orders (
  id int(11) NOT NULL AUTO_INCREMENT,
  amount decimal(6,2) DEFAULT NULL,
  date datetime NOT NULL,
  card_id int(11) NOT NULL,
  PRIMARY KEY (id)
);

DROP TABLE IF EXISTS book_orders;
CREATE TABLE  book_orders (
  book_id int(11) NOT NULL,
  order_id int(11) NOT NULL,
  quantity int(11) NOT NULL,
  PRIMARY KEY (book_id,order_id)
);

DROP TABLE IF EXISTS credit_cards;
CREATE TABLE  credit_cards (
  id int(11) NOT NULL AUTO_INCREMENT,
  type varchar(20) NOT NULL,
  name varchar(50) NOT NULL,
  number varchar(16) NOT NULL,
  expiry varchar(10) NOT NULL,
  ccv varchar(3) NOT NULL,
  user_id int(11) NOT NULL,
  PRIMARY KEY (id)
);