-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 24, 2017 at 07:17 AM
-- Server version: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `title` varchar(50) NOT NULL,
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(20) NOT NULL,
  `isbn` varchar(12) NOT NULL,
  `publisher` varchar(40) NOT NULL,
  `year` int(11) NOT NULL,
  `price` decimal(6,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `title`, `firstName`, `lastName`, `isbn`, `publisher`, `year`, `price`) VALUES
(1, 'Java Programming', 'Joe', 'Bloggs', '123456789012', 'Java Press', 2010, '21.99'),
(2, 'PHP Programming', 'Harry', 'Hughes', '234567890123', 'PHP Press', 2009, '19.99'),
(3, 'JavaScript Programming', 'Jane', 'Jones', '345678901234', 'JS Press', 2010, '23.00'),
(4, 'Game Programming', 'Kevin', 'Kelly', '456789012345', 'Game Press', 2006, '33.99'),
(5, 'CSS Design', 'Mary', 'Moore', '567890123456', 'CSS Press', 2005, '35.99');

-- --------------------------------------------------------

--
-- Table structure for table `book_orders`
--

CREATE TABLE `book_orders` (
  `book_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `book_orders`
--

INSERT INTO `book_orders` (`book_id`, `order_id`, `quantity`) VALUES
(1, 1, 1),
(1, 2, 3),
(1, 3, 2),
(2, 1, 1),
(2, 2, 3),
(2, 3, 4),
(3, 1, 1),
(3, 2, 3),
(3, 3, 1),
(4, 1, 1),
(4, 3, 1),
(5, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `credit_cards`
--

CREATE TABLE `credit_cards` (
  `id` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `name` varchar(50) NOT NULL,
  `number` varchar(16) NOT NULL,
  `expiry` varchar(10) NOT NULL,
  `ccv` varchar(3) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `credit_cards`
--

INSERT INTO `credit_cards` (`id`, `type`, `name`, `number`, `expiry`, `ccv`, `user_id`) VALUES
(1, 'Joe Bloggs', '1234567890123456', 'Visa', '12/12', '222', 2),
(2, 'Joe Bloggs Business', '0987654321098765', 'Master Card', '11/11', '876', 2),
(3, 'Fred Bloggs', '1234123412341234', 'Visa', '10/10', '123', 2),
(4, 'Joe Bloggs Savings', '9876987698769876', 'Visa', '09/09', '234', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `amount` decimal(6,2) DEFAULT NULL,
  `date` datetime NOT NULL,
  `card_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `amount`, `date`, `card_id`) VALUES
(1, '134.96', '2017-02-24 00:00:00', 3),
(2, '194.94', '2017-02-24 00:00:00', 1),
(3, '180.93', '2017-02-24 00:00:00', 4);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `role`) VALUES
(1, 'joe@bloggs.com', '$2y$10$3y5lF8kbtXJsEVa.obCiqeOuNQwJu2BJrEV8ykqbYIJjskD.Gl8Gy', 'user'),
(2, 'mary@bloggs.com', '$2y$10$HRIlA04DIaBafirCgS95xO/2TlsN0JyLyxofhpogKnMePt55FT9VO', 'user'),
(3, 'ciara@bloggs.com', '$2y$10$oBohqWtT8wQzunmnIkwNj.kfBRITlH7aKjU6D9eTUcOYmHz7m4fEC', 'staff');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book_orders`
--
ALTER TABLE `book_orders`
  ADD PRIMARY KEY (`book_id`,`order_id`);

--
-- Indexes for table `credit_cards`
--
ALTER TABLE `credit_cards`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `credit_cards`
--
ALTER TABLE `credit_cards`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
