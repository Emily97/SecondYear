<?php

require_once 'utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCart.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCartItem.php';

start_session();

try {
    //---------------------------------------------------------------------------------------------
    // make sure the user has a shopping cart to update
    //---------------------------------------------------------------------------------------------
    $cart = NULL;
    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    if ($cart == NULL || $cart->isEmpty()) {
        throw new Exception("Illegal request.");
    }

    //---------------------------------------------------------------------------------------------
    // update cart items
    //---------------------------------------------------------------------------------------------
    $items = $cart->getItems();
    foreach ($items as $item) {
        // get name of quantity text field for this item
        $key = "book-id-" . $item->getBookId();

        // validate the contents of quantity text field for this item
        $quantity = filter_input(INPUT_POST, $key, FILTER_SANITIZE_NUMBER_INT);
        if ($quantity === NULL || $quantity === FALSE) {
            throw new Exception("Quantity required.");
        }
        $quantity = filter_var($quantity, FILTER_VALIDATE_INT);
        if ($quantity === FALSE) {
            throw new Exception("Invalid quantity.");
        }

        // update quantity for this item
        $cart->updateCart($item->getBookId(), $quantity);
    }

    header('Location: '.SITE_PATH.'/view_cart.php');
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
    require SITE_ROOT . SITE_PATH . '/view_cart.php';
}
?>
