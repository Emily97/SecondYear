<?php
define("SITE_ROOT", "D:/Apache/htdocs");
define("SITE_PATH", "/staff/john/ShoppingCart");
?>