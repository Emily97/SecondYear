<footer class="footer">
    <h6>&copy; Acme Inc, 2016</h6>
</footer>
