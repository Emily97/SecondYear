<script type="text/javascript" src="<?php echo SITE_PATH; ?>/scripts/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="<?php echo SITE_PATH; ?>//scripts/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo SITE_PATH; ?>//scripts/main.js"></script>