<nav class="navbar navbar-default">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">

        <ul class="nav navbar-nav">
        <?php
        require_once SITE_ROOT . SITE_PATH . '/utils/session.php';

        if (!is_logged_in()) {
            echo '<li><a href="'.SITE_PATH.'/view_books.php">View Books</a></li>';
            echo '<li><a href="'.SITE_PATH.'/view_cart.php">View Cart</a></li>';
            echo '<li><a href="'.SITE_PATH.'/login_form.php">Login</a></li>';
            echo '<li><a href="'.SITE_PATH.'/register_form.php">Register</a></li>';
        }
        else {
            $user = $_SESSION['user'];

            if ($user['role'] === 'user') {
                echo '<li><a href="'.SITE_PATH.'/home.php">Home</a></li>';
                echo '<li><a href="'.SITE_PATH.'/view_books.php">View Books</a></li>';
                echo '<li><a href="'.SITE_PATH.'/view_cart.php">View Cart</a></li>';
                echo '<li><a href="'.SITE_PATH.'/logout.php">Logout</a></li>';
            }
            else if ($user['role'] === 'staff') {
                echo '<li><a href="'.SITE_PATH.'/admin/home.php">Home</a></li>';
                echo '<li><a href="'.SITE_PATH.'/admin/view_books.php">View Catalogue</a></li>';
                echo '<li><a href="'.SITE_PATH.'/logout.php">Logout</a></li>';
            }
        }
        ?>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>