<?php

require_once 'utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';
require_once SITE_ROOT . SITE_PATH . '/classes/DB.php';
require_once SITE_ROOT . SITE_PATH . '/classes/BookTable.php';

start_session();

try {
    $connection = DB::getConnection();
    $booksTable = new BookTable($connection);
    $books = $booksTable->getBooks();
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php require SITE_ROOT . SITE_PATH . '/utils/styles.php'; ?>
        <?php require SITE_ROOT . SITE_PATH . '/utils/scripts.php'; ?>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/header.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/toolbar.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <h2>Books</h2>
                    <?php 
                    if (isset($errorMessage)) {
                        echo '<p class="error">' . $errorMessage . '</p>'; 
                    }
                    if (isset($books) && is_array($books) && !empty($books)) {
                    ?>
                        <table class="table table-books">
                            <tr>
                                <th>Title</th>
                                <th>First Name</th>
                                <th>Last Name</th>
                                <th>ISBN</th>
                                <th>Publisher</th>
                                <th>Year</th>
                                <th>Price</th>
                                <th></th>
                            </tr>
                        <?php
                        foreach ($books as $book) {
                        ?>
                            <tr>
                                <td><?php echo $book['title']; ?></td>
                                <td><?php echo $book['firstName']; ?></td>
                                <td><?php echo $book['lastName']; ?></td>
                                <td><?php echo $book['isbn']; ?></td>
                                <td><?php echo $book['publisher']; ?></td>
                                <td><?php echo $book['year']; ?></td>
                                <td><?php echo $book['price']; ?></td>
                                <td>
                                    <a class="btn btn-default" href="add_to_cart.php?id=<?php echo $book['id']; ?>">Add to cart</a>
                                </td>
                            </tr>
                        <?php
                        }
                        ?>
                        </table>
                    <?php
                    }
                    else if (isset($books) && is_array($books) && empty($books)) {
                        echo "<p>There are no books in the database.</p>";
                    }
                    ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/footer.php'; ?>
                </div>
            </div>
        </div>
    </body>
</html>