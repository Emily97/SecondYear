<?php

require_once 'utils/config.php';
require_once SITE_ROOT . SITE_PATH . '/utils/session.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCart.php';
require_once SITE_ROOT . SITE_PATH . '/classes/ShoppingCartItem.php';
require_once SITE_ROOT . SITE_PATH . '/classes/DB.php';
require_once SITE_ROOT . SITE_PATH . '/classes/BookTable.php';

try {
    start_session();


    if (isset($_SESSION['cart'])) {
        $cart = $_SESSION['cart'];
    }
    else {
        $cart = new ShoppingCart();
        $_SESSION['cart'] = $cart;
    }

    $connection = DB::getConnection();
    $bookTable = new BookTable($connection);
    $books = $bookTable->getBooks();
}
catch (Exception $ex) {
    $errorMessage = $ex->getMessage();
}
?>
<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title></title>
        <?php require SITE_ROOT . SITE_PATH . '/utils/styles.php'; ?>
        <?php require SITE_ROOT . SITE_PATH . '/utils/scripts.php'; ?>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/header.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/toolbar.php'; ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <h2>Shopping cart</h2>
                    <?php                
                    if (isset($errorMessage)) {
                        echo '<p class="error">' . $errorMessage . '</p>'; 
                    }
                    $items = $cart->getItems();
                    if (isset($items) && is_array($items) && !empty($items)) {
                        $totalAmount = 0.0;

                        echo '<form action="' . SITE_PATH . '/update_cart.php" method="POST">';
                        echo '<table class="table table-cart">';
                        echo '<tr>
                                <th>Title</th>
                                <th>Unit price</th>
                                <th>Quantity</th>
                                <th>Price</th>
                              </tr>';

                        foreach ($items as $item) {
                            $book = $books[ $item->getBookId() ];
                            $price = $book['price'];
                            $linePrice = $price * $item->getQuantity();

                            echo '<tr>';
                            echo '<td>'.$book['title'].'</td>';
                            echo '<td>'.number_format((float)$price, 2, '.', '').'</td>';
                            echo '<td><input class="input-quantity"
                                             type="text"
                                             name="book-id-'.$item->getBookId().'"
                                             value="'.$item->getQuantity().'" />
                                  </td>';
                            echo '<td>'.number_format((float)$linePrice, 2, '.', '').'</td>';
                            echo '</tr>';

                            $totalAmount = $totalAmount + $linePrice;
                        }
                        echo '<tr>
                                  <td></td>
                                  <td></td>
                                  <th>Total price</th>
                                  <td>'.number_format((float)$totalAmount, 2, '.', '').'</td>
                                  </tr>';
                        echo '<tr>
                                  <td>
                                      <input type="submit"
                                             name="submit"
                                             class="btn btn-primary"
                                             value="Update Cart" />

                                      <a class="btn btn-default" href="checkout_form.php">Checkout</a>
                                  </td>
                                  <td></td>
                                  <td></td>
                                  <td></td>
                              </tr>';
                        echo '</table>';
                        echo '<p></p>';
                        echo '</form>';
                    }
                    else if (isset($items) && is_array($items) && empty($items)) {
                        echo '<p>Your shopping cart is empty.</p>';
                    }
                    ?>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-12">
                    <?php require SITE_ROOT . SITE_PATH . '/utils/footer.php'; ?>
                </div>
            </div>
        </div>
    </body>
</html>